<?php

use App\Http\Controllers\Api\PaymentController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\TelegramController;
use App\Http\Controllers\Api\MovieRequestController;
use App\Models\Package;
use App\Models\User;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});
// API Webhook Telegram
Route::post('/telegram/webhook', [TelegramController::class, 'handleWebhook']);

// API Integrated Midtrans (dipanggil dari halaman /checkout di dalam TWA)
Route::middleware('telegram.auth')->post('/payment/create', [PaymentController::class, 'createTransaction']);
Route::post('/payment/callback', [PaymentController::class, 'handleCallback']);

// Daftar paket untuk ditampilkan di TWA (tab Paket & halaman checkout)
Route::get('/packages', function () {
    return response()->json(
        Package::where('is_active', true)->orderBy('price')->get()
    );
});

Route::get('/packages/{package}', function (Package $package) {
    if (!$package->is_active) {
        return response()->json(['message' => 'Paket tidak tersedia'], 404);
    }
    return response()->json($package);
});

// Request judul film baru (hanya untuk user yang berlangganan aktif)
Route::middleware('telegram.auth')->post('/movie-requests', [MovieRequestController::class, 'store']);

// Riwayat request film milik user
Route::middleware('telegram.auth')->get('/movie-requests', [MovieRequestController::class, 'index']);

// Integration TWA
Route::middleware('telegram.auth')->get('/user/status', function (Request $request) {
    $user = $request->attributes->get('verified_telegram_user');

    $isSubscribed = $user && $user->is_subscribed && $user->expired_at && $user->expired_at->isFuture();

    return response()->json([
        'is_subscribed' => $isSubscribed,
        'user' => $user ? [
            'first_name' => $user->first_name,
            'expired_at' => $user->expired_at ? $user->expired_at->format('Y-m-d H:i:s') : null,
        ] : null
    ]);
});
